# LaTeX2HTML 2012 (1.2)
# Associate images original text with physical files.


$key = q/epsfbox{tm.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="370" HEIGHT="234" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\epsfbox{tm.eps}">|; 

1;

